const { Sequelize, Model, DataTypes } = require('sequelize');
const sequelize = new Sequelize('sqlite::memory:');

// ---------- User Model -----------
class User extends Model {}
User.init({
    username: DataTypes.STRING,
    password: DataTypes.STRING
}, { sequelize });

// ---------- Twitter Model -----------
class Tweet extends Model {}
Tweet.init({
    content: DataTypes.STRING,
    authorName: DataTypes.STRING,
    timeCreated: DataTypes.DATE
}, { sequelize });
// important - we havent created authorID yet!