const { Router } = require('express')
const router = Router()
const { User, Tweet } = require('../models/models.js')

// ----------- print function ------------
function print(data1, data2) {
    if (data2 == undefined) {
        console.log(data1)
    } else {
        console.log(data2)
        console.log(data1)
    }
}

// ---------- root ------------
router.get('/', async function(req, res) {
    await Tweet.sync()
    let tweets = await Tweet.findAll({ include: User })
    let data = { tweets }

    res.render('pages/index.ejs', data)
})

// ----------- creating User Page ------------
router.get('/createUser', function(req, res) {

    res.render('pages/createUser.ejs')
})

// ----------- creating User ------------
router.post('/createUser', async function(req, res) {

    let username = req.body.username
    let password = req.body.password

    console.log(req.body)

    await User.sync()
    let user = await User.create({
        username,
        password
    })

    console.log(user.toJSON())
    res.redirect('/createUser')
})

// ----------- creating Tweet page ------------
router.get('/createTweet', function(req, res) {

    res.render('pages/createTweet.ejs')
})

// ----------- creating Tweet ------------
router.post('/createTweet', async function(req, res) {

    let username = req.body.username
    let password = req.body.password
    let content = req.body.content

    print(req.body, 'createTweet req.body')

    let user = await User.findOne({
        where: { username, password }
    })

    print(user, 'createTweet User retrieval')

    if (user) {

        let tweet = await Tweet.create({
            content,
            timeCreated: new Date(),
            fuckingId: user.id

        })
        console.log(tweet)
        res.redirect('/')
    } else {
        res.redirect('/error')
    }
})

module.exports = router