console.log('Beginning of Models File\n')
const { Model, DataTypes } = require('sequelize')
const sequelize = require('../db.js')

class User extends Model {}

User.init({
    username: DataTypes.STRING,
    password: DataTypes.STRING
}, { sequelize });

(async() => {
    await User.sync()
})()

class Tweet extends Model {}

Tweet.init({
    content: DataTypes.STRING,
    timeCreated: DataTypes.DATE
}, { sequelize });

(async() => {
    await Tweet.sync()
})()

User.hasMany(Tweet, { foreignKey: 'fuckingId' })
Tweet.belongsTo(User)

module.exports = { User, Tweet }
console.log('\nEnd of Models File')